﻿namespace TBIC
{
    partial class TransactionHistory
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnTransactionHistory = new System.Windows.Forms.Button();
            this.btnPointofSale = new System.Windows.Forms.Button();
            this.picTransacHistoryBG = new System.Windows.Forms.PictureBox();
            this.txtSearchBoxSearchHistory = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lblIDs = new System.Windows.Forms.Label();
            this.lblUsernameNumba = new System.Windows.Forms.Label();
            this.lblUserID = new System.Windows.Forms.Label();
            this.lblUsername = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.picTransacHistoryBG)).BeginInit();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnTransactionHistory
            // 
            this.btnTransactionHistory.BackColor = System.Drawing.Color.Transparent;
            this.btnTransactionHistory.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnTransactionHistory.FlatAppearance.BorderSize = 0;
            this.btnTransactionHistory.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTransactionHistory.Image = global::TBIC.Properties.Resources.TransactionHistoryBtnUI;
            this.btnTransactionHistory.Location = new System.Drawing.Point(1069, 183);
            this.btnTransactionHistory.Name = "btnTransactionHistory";
            this.btnTransactionHistory.Size = new System.Drawing.Size(214, 63);
            this.btnTransactionHistory.TabIndex = 4;
            this.btnTransactionHistory.UseVisualStyleBackColor = false;
            // 
            // btnPointofSale
            // 
            this.btnPointofSale.BackColor = System.Drawing.Color.Transparent;
            this.btnPointofSale.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnPointofSale.FlatAppearance.BorderSize = 0;
            this.btnPointofSale.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPointofSale.Image = global::TBIC.Properties.Resources.PointofSaleBtnUI;
            this.btnPointofSale.Location = new System.Drawing.Point(1069, 122);
            this.btnPointofSale.Name = "btnPointofSale";
            this.btnPointofSale.Size = new System.Drawing.Size(214, 44);
            this.btnPointofSale.TabIndex = 3;
            this.btnPointofSale.UseVisualStyleBackColor = false;
            // 
            // picTransacHistoryBG
            // 
            this.picTransacHistoryBG.Image = global::TBIC.Properties.Resources.TransactionHistoryBG;
            this.picTransacHistoryBG.Location = new System.Drawing.Point(-3, 0);
            this.picTransacHistoryBG.Name = "picTransacHistoryBG";
            this.picTransacHistoryBG.Size = new System.Drawing.Size(1268, 685);
            this.picTransacHistoryBG.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picTransacHistoryBG.TabIndex = 0;
            this.picTransacHistoryBG.TabStop = false;
            // 
            // txtSearchBoxSearchHistory
            // 
            this.txtSearchBoxSearchHistory.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSearchBoxSearchHistory.Location = new System.Drawing.Point(264, 113);
            this.txtSearchBoxSearchHistory.Multiline = true;
            this.txtSearchBoxSearchHistory.Name = "txtSearchBoxSearchHistory";
            this.txtSearchBoxSearchHistory.Size = new System.Drawing.Size(274, 31);
            this.txtSearchBoxSearchHistory.TabIndex = 14;
            this.txtSearchBoxSearchHistory.Text = "Finding History";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Controls.Add(this.lblIDs);
            this.panel3.Controls.Add(this.lblUsernameNumba);
            this.panel3.Controls.Add(this.lblUserID);
            this.panel3.Controls.Add(this.lblUsername);
            this.panel3.Location = new System.Drawing.Point(1122, 12);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(118, 28);
            this.panel3.TabIndex = 26;
            // 
            // lblIDs
            // 
            this.lblIDs.AutoSize = true;
            this.lblIDs.Location = new System.Drawing.Point(20, 14);
            this.lblIDs.Name = "lblIDs";
            this.lblIDs.Size = new System.Drawing.Size(21, 13);
            this.lblIDs.TabIndex = 14;
            this.lblIDs.Text = "ID:";
            // 
            // lblUsernameNumba
            // 
            this.lblUsernameNumba.AutoSize = true;
            this.lblUsernameNumba.Location = new System.Drawing.Point(9, 2);
            this.lblUsernameNumba.Name = "lblUsernameNumba";
            this.lblUsernameNumba.Size = new System.Drawing.Size(32, 13);
            this.lblUsernameNumba.TabIndex = 13;
            this.lblUsernameNumba.Text = "User:";
            // 
            // lblUserID
            // 
            this.lblUserID.AutoSize = true;
            this.lblUserID.Location = new System.Drawing.Point(41, 14);
            this.lblUserID.Name = "lblUserID";
            this.lblUserID.Size = new System.Drawing.Size(19, 13);
            this.lblUserID.TabIndex = 12;
            this.lblUserID.Text = "69";
            // 
            // lblUsername
            // 
            this.lblUsername.AutoSize = true;
            this.lblUsername.Location = new System.Drawing.Point(41, 2);
            this.lblUsername.Name = "lblUsername";
            this.lblUsername.Size = new System.Drawing.Size(22, 13);
            this.lblUsername.TabIndex = 11;
            this.lblUsername.Text = "Me";
            // 
            // TransactionHistory
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1264, 641);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.txtSearchBoxSearchHistory);
            this.Controls.Add(this.btnTransactionHistory);
            this.Controls.Add(this.btnPointofSale);
            this.Controls.Add(this.picTransacHistoryBG);
            this.Name = "TransactionHistory";
            this.Text = "TransactionHistory";
            ((System.ComponentModel.ISupportInitialize)(this.picTransacHistoryBG)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox picTransacHistoryBG;
        private System.Windows.Forms.Button btnPointofSale;
        private System.Windows.Forms.Button btnTransactionHistory;
        private System.Windows.Forms.TextBox txtSearchBoxSearchHistory;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lblIDs;
        private System.Windows.Forms.Label lblUsernameNumba;
        public System.Windows.Forms.Label lblUserID;
        public System.Windows.Forms.Label lblUsername;
    }
}